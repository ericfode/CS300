package com.efode.linkedList.test;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ AddTests.class, GetTests.class, RemoveTests.class })
public class AllTests {

}
